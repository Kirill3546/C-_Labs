﻿
namespace Pz1.TaskSystem
{
    public interface ITaskeable
    {
        void StartTask();

        void StopTask();
    }
}